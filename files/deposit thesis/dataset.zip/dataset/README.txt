README File For 'Dataset for PhD Thesis "Energy Budgeting for Intermittently-Powered Systems"'

Dataset DOI: <To be obtained>

ReadMe Author: Jie Zhan, University of Southampton [ORCID: 0000-0002-9196-757X] [email: j.zhan@soton.ac.uk]


This dataset supports Chapter 5 of the PhD thesis:

AUTHORS: Jie Zhan

TITLE: Energy Budgeting for Intermittently-Powered Systems

Dataset for Chapter 3 and Chapter 4 of the thesis is already published. DOI: 10.5258/SOTON/D1785


This dataset contains:

'variable_data.csv': Data supporting Figure 5.1 \Delta V_task varying linearly with the data size in AES 128-bit encryption.

'pv_curve.csv': Data supporting Figure 5.2 An I-V curve of a glass-type amorphous PV panel (Sanyo AM-1417CA, 35mm x 13.9mm) under a white LED lighting condition.

'perf.csv': Data supporting Figure 5.3 Numbers of completed and failed operations of DEBS Low, Samoyed, DEBS High, and OPTIC Oracle given random data sizes and configurations and a PV supply in a 10s simulation. 

'cap.csv': Data supporting Figure 5.5 Number of completed operations of Samoyed, DEBS High, and the OPTIC Oracle with capacitance reduction.

'profiling_accuracy.csv': Data supporting Figure 5.11 Error Distribution of OPTIC's Runtime Energy Profiling given a PV supply, compared to the "Naive" disconnecting-supply method.

'analog.csv', 'digital.csv': Data supporting Figure 5.12 A voltage trace of OPTIC adapting to a new operation on a new device.

'cap_test_aes.csv', 'cap_test_dma.csv', 'cap_test_radio.csv': Data supporting Figure 5.13 Effect of Capacitor Degradation on OPTIC and DEBS.

'datasize.csv': Data supporting Figure 5.14 Relative Completion Rates of Samoyed, DEBS, and OPTIC with variable data sizes and a PV supply. 



Date of data collection: July 2021 - December 2021


Information about geographic location of data collection:  UK


Licence: CC BY 4.0


Related projects:
EPSRC Grant EP/P010164/1
CSC Grant 201706310132


Date that the file was created: June, 2022